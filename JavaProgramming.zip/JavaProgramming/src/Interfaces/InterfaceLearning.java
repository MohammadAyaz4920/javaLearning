package Interfaces;

interface animal
{
	void sleep();
	void eat();
}

class Dog implements animal
{
	@Override
	public void sleep()
	{
		System.out.println("Dog sleeps");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Dog eats");
	}
}

public class InterfaceLearning {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		animal dog=new Dog();
		dog.sleep();
		dog.eat();

	}

}
