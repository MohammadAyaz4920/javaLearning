package Programs;

public class ReverseStringBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="ayaz";
		StringBuilder s=new StringBuilder(str);
		s.reverse();
		System.out.println(s);
	}

}
