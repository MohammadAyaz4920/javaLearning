package practice;


import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class StringCompression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="aabbccddffeeeeeeeeeeeeeeeeeeeeeee";
		LinkedHashMap<Character,Integer>lm=new LinkedHashMap<Character,Integer>();
		for(int i=0;i<str.length();i++)
		{
			
			if(lm.get(str.charAt(i))!=null)
			{
				lm.put(str.charAt(i), lm.get(str.charAt(i))+1);
			}
			else
			{
				lm.put(str.charAt(i), 1);
			}
		}
		StringBuffer sb=new StringBuffer();
		for(Entry<Character, Integer> entry: lm.entrySet())
		{
			sb.append(entry.getKey());
			sb.append(entry.getValue());
		}
		System.out.println(sb.toString());

	}

}
