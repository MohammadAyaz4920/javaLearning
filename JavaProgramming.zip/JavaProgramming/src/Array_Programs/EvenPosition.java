package Array_Programs;

public class EvenPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[] {10,20,30,40,50,60,70};
		for(int i=1;i<arr.length;i=i+2)
		{
			System.out.println(arr[i]);
		}
	}

}
