package AbstractClasses;



abstract class Animal{
	
	String name;
	
	Animal(String name)
	{
		this.name=name;
	}
	
	void Display()
	{
		
	}
	void sound()
	{
		System.out.println("The animal roars");
	}
}

class Dog extends Animal{
	
	Dog(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	void sound()
	{
		System.out.println("the dog barks");
	}
}

public class abstractMethodLearning  {
	
	public static void Main(String[] args)
	{
	Dog a=new Dog("Dog");
	a.Display();
	a.sound();
	
	}

}