package AbstractClasses;


abstract class Shape
{
	void display()
	{
		System.out.println("Shape");
	}
	
}

class circle extends Shape
{
	void draw()
	{
		System.out.println("Circle");
	}
}
public class AbstractClassExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Shape shape=new Shape();  
		
		circle circle=new circle();
		circle.draw();
		circle.display();

	}

}
