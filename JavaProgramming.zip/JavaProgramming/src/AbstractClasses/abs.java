package AbstractClasses;




public class abs  {
	
	public static void Main(String[] args)
	{
	Dog a=new Dog("Dog");
	a.Display();
	a.sound();
	
	}

}
