package AbstractClasses;

public class abcd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog a=new Dog("Dog");
		a.Display();
		a.sound();
		

	}

}
